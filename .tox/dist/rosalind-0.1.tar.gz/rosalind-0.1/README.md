# Rosalind
A collection of my solutions to the problems on Rosalind.info
