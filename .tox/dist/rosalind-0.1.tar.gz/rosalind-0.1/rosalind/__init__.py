"""Solutions to Rosalind.info problems"""
__version__ = "0.1"

